import asyncio
import random
import time

from backend.app.services.buzzer_service import BuzzerService
from backend.app.services.game_service import GameService, Partida
from backend.app.services.question_service import QuestionService


def nova_partida():
    return Partida(QuestionService(), rng=random.Random(1))


def na_vez(equipe="azul"):
    partida = nova_partida()
    assert partida.iniciar().evento == "iniciar"
    assert partida.avancar().evento == "sortear"
    assert partida.estado.para_dict(True)["gabarito"] is None
    assert partida.liberar_buzzer().evento == "liberar_buzzer"
    toque = partida.apertar(equipe, 1700000000000, 1700000000050)
    assert toque.ok
    assert toque.evento == "buzzer_acionado"
    assert partida.estado.primeiro_toque["timestamp"] == 1700000000000
    assert partida.estado.primeiro_toque["timestamp_servidor"] == 1700000000050
    return partida


def test_buzzer_recusa_toque_fora_da_janela():
    partida = nova_partida()
    partida.iniciar()
    partida.avancar()
    recusado = partida.apertar("azul", 10, 11)
    assert not recusado.ok
    assert partida.estado.primeiro_toque is None
    assert partida.estado.buzzer_aberto is False


def test_somente_o_primeiro_toque_vale():
    partida = na_vez("azul")
    segundo = partida.apertar("vermelho", 1, 99999)
    assert not segundo.ok
    assert partida.estado.primeiro_toque["equipe"] == "azul"
    assert partida.estado.equipe_da_vez == "azul"
    assert partida.estado.buzzer_aberto is False


def test_acerto_soma_10_erro_soma_zero_e_gabarito_fica_no_painel():
    partida = na_vez("azul")
    correta = partida.estado.pergunta["resposta_correta"]
    errada = "A" if correta != "A" else "B"

    outra = nova_partida()
    outra.iniciar()
    outra.avancar()
    outra.liberar_buzzer()
    outra.apertar("vermelho", 20, 21)
    erro = outra.validar(errada if outra.estado.pergunta["resposta_correta"] != errada else "C")
    assert erro.ok
    assert outra.estado.resultado == "erro"
    assert outra.estado.placar == {"azul": 0, "vermelho": 0}

    acerto = partida.validar(correta)
    assert acerto.evento == "validar_resposta"
    assert "atualizar_placar" in acerto.extras
    assert partida.estado.placar["azul"] == 10
    assert partida.estado.para_dict(True)["gabarito"] == correta
    assert partida.estado.para_dict(False)["gabarito"] is None
    assert "resposta_correta" not in partida.estado.para_dict(False)["pergunta"]


def test_passar_vale_20_e_quem_passou_nao_responde():
    partida = na_vez("azul")
    passe = partida.passar("azul")
    assert passe.evento == "passar"
    assert partida.estado.equipe_da_vez == "vermelho"
    assert partida.estado.valor == 20
    assert partida.passar("azul").ok is False
    assert partida.responder("azul").ok is False
    assert partida.responder("vermelho").ok is True
    partida.validar(partida.estado.pergunta["resposta_correta"])
    assert partida.estado.placar == {"azul": 0, "vermelho": 20}


def test_cada_grupo_passa_uma_vez_e_o_segundo_passe_descarta():
    partida = na_vez("azul")
    assert partida.passar("azul").ok
    segundo = partida.passar("vermelho")
    assert segundo.ok
    assert partida.estado.fase == "descartada"
    assert partida.estado.placar == {"azul": 0, "vermelho": 0}
    assert "encerrar_rodada" in segundo.extras
    assert partida.responder("azul").ok is False
    assert partida.validar("A").ok is False


def test_sem_aperto_em_10_segundos_descarta_sem_ponto():
    partida = nova_partida()
    partida.iniciar()
    partida.avancar()
    partida.liberar_buzzer()
    fim = partida.concluir_timer("valendo")
    assert fim.evento == "encerrar_rodada"
    assert partida.estado.fase == "descartada"
    assert "10 segundos" in partida.estado.mensagem
    assert partida.estado.placar == {"azul": 0, "vermelho": 0}


def test_dez_perguntas_sem_repetir_e_depois_encerra():
    partida = nova_partida()
    partida.iniciar()
    ids = []
    for _ in range(10):
        assert partida.avancar().evento == "sortear"
        ids.append(partida.estado.pergunta["id"])
        assert partida.concluir_timer("leitura").evento == "liberar_buzzer"
        assert partida.concluir_timer("valendo").evento == "encerrar_rodada"
    assert len(set(ids)) == 10
    final = partida.avancar()
    assert final.evento == "encerrar_rodada"
    assert partida.estado.fase == "encerrada"
    assert partida.estado.vencedor == "empate"


def test_tablet_nao_inicia_e_nova_partida_zera_o_placar():
    partida = na_vez("azul")
    partida.julgar(True)
    assert partida.estado.placar["azul"] == 10
    assert partida.aplicar("buzzer", {"evento": "iniciar"}).ok is False
    assert partida.estado.placar["azul"] == 10
    partida.iniciar()
    assert partida.estado.placar == {"azul": 0, "vermelho": 0}
    assert partida.estado.rodada == 0
    assert len(partida.estado.fila) == 10


def test_servico_de_buzzer_guarda_o_timestamp():
    from backend.app.models.game import GameState

    estado = GameState(fase="valendo", buzzer_aberto=True)
    ok, _mensagem = BuzzerService().registrar(estado, "vermelho", 321, 654)
    assert ok
    assert estado.primeiro_toque == {
        "equipe": "vermelho",
        "timestamp": 321,
        "timestamp_servidor": 654,
    }
    de_novo, mensagem = BuzzerService().registrar(estado, "azul", 1, 2)
    assert de_novo is False
    assert "primeiro" in mensagem


def test_cronometros_do_servidor():
    async def cenario():
        class Captura:
            def __init__(self):
                self.eventos = []

            async def broadcast(self, evento, mensagem, estados, ok=True):
                self.eventos.append(evento)

            async def send_personal(self, websocket, message):
                self.eventos.append(message["evento"])

        jogo = GameService(Captura(), tick_seconds=0.02, rng=random.Random(2))

        async def esperar(condicao, timeout=2.0):
            limite = time.time() + timeout
            while time.time() < limite:
                if condicao():
                    return True
                await asyncio.sleep(0.01)
            return False

        await jogo.handle("painel", {"evento": "iniciar"}, None)
        await jogo.handle("painel", {"evento": "sortear"}, None)
        assert await esperar(lambda: jogo.partida.estado.fase == "valendo")
        await jogo.handle(
            "buzzer",
            {"evento": "apertar_buzzer", "equipe": "vermelho", "timestamp": 4242},
            None,
        )
        assert jogo.partida.estado.primeiro_toque["equipe"] == "vermelho"
        assert jogo.partida.estado.primeiro_toque["timestamp"] == 4242
        assert await esperar(lambda: jogo.partida.estado.fase == "escolher")
        assert "buzzer_acionado" in jogo.manager.eventos

        jogo.cancelar_timers()
        tarefa = jogo._task
        if tarefa:
            await asyncio.wait([tarefa], timeout=1)

        outro = GameService(Captura(), tick_seconds=0.02, rng=random.Random(3))
        await outro.handle("painel", {"evento": "iniciar"}, None)
        await outro.handle("painel", {"evento": "sortear"}, None)
        assert await esperar(lambda: outro.partida.estado.fase == "descartada")
        assert outro.partida.estado.placar == {"azul": 0, "vermelho": 0}
        assert "encerrar_rodada" in outro.manager.eventos
        outro.cancelar_timers()
        if outro._task:
            await asyncio.wait([outro._task], timeout=1)

    asyncio.run(cenario())
