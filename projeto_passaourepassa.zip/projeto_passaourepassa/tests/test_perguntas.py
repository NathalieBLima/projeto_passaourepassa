import json
from pathlib import Path

import pytest

from backend.app.models.question import CATEGORIAS
from backend.app.services.question_service import CAMINHO_PADRAO, QuestionService


def test_banco_tem_30_perguntas_de_8_anos():
    servico = QuestionService()
    perguntas = servico.todas()
    assert len(perguntas) == 30
    assert {item["categoria"] for item in perguntas} == CATEGORIAS
    ids = [item["id"] for item in perguntas]
    assert len(set(ids)) == 30
    for item in perguntas:
        assert set(item["alternativas"]) == {"A", "B", "C", "D"}
        assert item["resposta_correta"] in item["alternativas"]
        assert item["pontos"] == 10
        assert item["tempo_leitura"] == 5
        assert servico.obter(item["id"])["resposta_correta"] == item["resposta_correta"]


def test_arquivo_json_existe_no_caminho_padrao():
    bruto = json.loads(Path(CAMINHO_PADRAO).read_text(encoding="utf-8"))
    assert len(bruto) == 30


def test_banco_vazio_falha(tmp_path):
    caminho = tmp_path / "perguntas.json"
    caminho.write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError):
        QuestionService(caminho)
