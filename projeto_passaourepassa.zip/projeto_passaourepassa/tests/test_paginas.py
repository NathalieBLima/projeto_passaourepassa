import pytest
from fastapi.testclient import TestClient

from backend.app.container import jogo
from backend.main import app


@pytest.fixture
def client():
    jogo.reiniciar_para_testes()
    with TestClient(app) as cliente:
        yield cliente
    jogo.reiniciar_para_testes()


def test_paginas_e_arquivos(client):
    inicio = client.get("/")
    painel = client.get("/painel")
    buzzer = client.get("/buzzer")
    assert inicio.status_code == painel.status_code == buzzer.status_code == 200
    assert "Passa ou Repassa da Turma" in inicio.text
    assert "Liberar buzzer" in painel.text
    assert "RESPONDER" in buzzer.text
    assert client.get("/static/css/style.css").status_code == 200
    assert client.get("/static/sounds/buzz.wav").status_code == 200
    assert client.get("/static/js/painel.js").status_code == 200
    assert client.get("/static/js/buzzer.js").status_code == 200


def test_websocket_entrega_o_estado_e_recusa_acao_do_tablet(client):
    with client.websocket_connect("/ws/painel") as painel:
        chegada = painel.receive_json()
        assert chegada["evento"] == "estado"
        assert chegada["estado"]["placar"] == {"azul": 0, "vermelho": 0}
        painel.send_json({"evento": "iniciar"})
        resposta = painel.receive_json()
        assert resposta["ok"] is True
        assert resposta["evento"] == "iniciar"
        assert resposta["estado"]["iniciada"] is True
        assert len(resposta["estado"]["historico"]) >= 1

    with client.websocket_connect("/ws/buzzer") as tablet:
        tablet.receive_json()
        tablet.send_json({"evento": "iniciar"})
        recusa = tablet.receive_json()
        assert recusa["ok"] is False
        assert recusa["estado"]["gabarito"] is None
