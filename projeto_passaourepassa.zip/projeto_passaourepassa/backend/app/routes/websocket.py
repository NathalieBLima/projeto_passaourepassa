"""Canal em tempo real do painel e do tablet."""

from __future__ import annotations

import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.app.container import jogo, manager


router = APIRouter()
logger = logging.getLogger("passaourepassa")


@router.websocket("/ws/{papel}")
async def canal(websocket: WebSocket, papel: str):
    if papel not in ("painel", "buzzer"):
        await websocket.close(code=1008)
        return

    await manager.connect(websocket, papel)
    await manager.send_personal(
        websocket,
        {
            "evento": "estado",
            "ok": True,
            "mensagem": jogo.partida.estado.mensagem,
            "estado": jogo.estado_para(papel),
        },
    )
    try:
        while True:
            dados = await websocket.receive_json()
            try:
                await jogo.handle(papel, dados, websocket)
            except Exception:
                logger.exception("Erro ao tratar evento")
                await manager.send_personal(
                    websocket,
                    {
                        "evento": "erro",
                        "ok": False,
                        "mensagem": "Não consegui processar essa ação.",
                        "estado": jogo.estado_para(papel),
                    },
                )
    except WebSocketDisconnect:
        manager.disconnect(websocket, papel)
    except Exception:
        manager.disconnect(websocket, papel)
