"""Páginas do jogo."""

from __future__ import annotations

import socket
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates


BASE = Path(__file__).resolve().parents[2]
templates = Jinja2Templates(directory=str(BASE / "templates"))
router = APIRouter()


def listar_ips() -> list:
    encontrados = []
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.2)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip and not ip.startswith("127."):
            encontrados.append(ip)
    except Exception:
        pass
    return encontrados


def _contexto(request: Request) -> dict:
    return {
        "ips": listar_ips(),
        "porta": request.url.port or 8000,
    }


@router.get("/")
def inicio(request: Request):
    return templates.TemplateResponse(request, "index.html", _contexto(request))


@router.get("/painel")
def painel(request: Request):
    return templates.TemplateResponse(request, "painel.html", _contexto(request))


@router.get("/buzzer")
def buzzer(request: Request):
    return templates.TemplateResponse(request, "buzzer.html", _contexto(request))
