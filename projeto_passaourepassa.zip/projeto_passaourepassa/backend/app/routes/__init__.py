"""Rotas HTTP e WebSocket."""
