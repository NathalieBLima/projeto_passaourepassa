"""Entrega os eventos ao painel da professora e ao tablet do buzzer."""

from __future__ import annotations

import logging

from fastapi import WebSocket


logger = logging.getLogger("passaourepassa")


class ConnectionManager:
    def __init__(self) -> None:
        self.conexoes = {"painel": set(), "buzzer": set()}

    async def connect(self, websocket: WebSocket, role: str) -> None:
        await websocket.accept()
        self.conexoes[role].add(websocket)
        logger.info("Conectado: %s (%s)", role, len(self.conexoes[role]))

    def disconnect(self, websocket: WebSocket, role: str) -> None:
        self.conexoes.get(role, set()).discard(websocket)

    async def send_personal(self, websocket: WebSocket, message: dict) -> None:
        try:
            await websocket.send_json(message)
        except Exception:
            logger.info("Falha ao enviar para um cliente.")

    async def broadcast(self, evento: str, mensagem: str, estados: dict, ok: bool = True) -> None:
        for role, estado in estados.items():
            payload = {
                "evento": evento,
                "ok": ok,
                "mensagem": mensagem,
                "estado": estado,
            }
            mortas = []
            for websocket in list(self.conexoes.get(role, ())):
                try:
                    await websocket.send_json(payload)
                except Exception:
                    mortas.append(websocket)
            for websocket in mortas:
                self.conexoes[role].discard(websocket)
