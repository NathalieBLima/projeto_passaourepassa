"""Aplicação do Passa ou Repassa da Turma."""
