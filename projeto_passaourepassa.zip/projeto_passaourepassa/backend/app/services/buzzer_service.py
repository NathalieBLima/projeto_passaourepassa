"""Registra só o primeiro toque válido, com o instante em milissegundos."""

from __future__ import annotations

from backend.app.models.game import nome_equipe


class BuzzerService:
    equipes = ("azul", "vermelho")

    def registrar(self, estado, equipe: str, timestamp_ms: int, timestamp_servidor: int) -> tuple:
        if equipe not in self.equipes:
            return False, "Equipe inválida."
        if estado.primeiro_toque is not None:
            return False, "O primeiro toque já foi registrado."
        if estado.fase != "valendo" or not estado.buzzer_aberto:
            return False, "O buzzer ainda não foi liberado."
        if equipe in estado.passaram:
            return False, "{0} já passou e não responde.".format(nome_equipe(equipe))

        estado.primeiro_toque = {
            "equipe": equipe,
            "timestamp": int(timestamp_ms),
            "timestamp_servidor": int(timestamp_servidor),
        }
        estado.buzzer_aberto = False
        estado.equipe_da_vez = equipe
        return True, "{0} apertou primeiro.".format(nome_equipe(equipe))
