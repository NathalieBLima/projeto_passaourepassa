"""Regras, perguntas e buzzer."""
