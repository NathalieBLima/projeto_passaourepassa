"""Regras da partida e os cronômetros controlados pelo servidor."""

from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field

from backend.app.models.game import (
    TEMPO_ANIMACAO,
    TEMPO_BUZZER,
    VALOR_PASSE,
    GameState,
    nome_equipe,
    outra_equipe,
)
from backend.app.services.buzzer_service import BuzzerService
from backend.app.services.question_service import QuestionService


logger = logging.getLogger("passaourepassa")

PERMISSOES = {
    "iniciar": {"painel"},
    "sortear": {"painel"},
    "proxima": {"painel"},
    "liberar_buzzer": {"painel"},
    "selecionar_resposta": {"painel"},
    "validar_resposta": {"painel"},
    "acertou": {"painel"},
    "errou": {"painel"},
    "passar": {"painel", "buzzer"},
    "apertar_buzzer": {"buzzer"},
    "responder": {"buzzer"},
}


@dataclass
class Outcome:
    ok: bool
    evento: str
    mensagem: str
    timer: tuple | None = None
    encerrar_timer: bool = False
    extras: list = field(default_factory=list)


def _falha(evento: str, mensagem: str) -> Outcome:
    return Outcome(False, evento, mensagem)


class Partida:
    """Máquina de estados síncrona. Quem chama decide quando armar o relógio."""

    def __init__(self, perguntas: QuestionService, rng: random.Random | None = None):
        self.perguntas = perguntas
        self.rng = rng or random.Random()
        self.buzzer = BuzzerService()
        self.estado = GameState()

    def aplicar(self, papel: str, dados: dict) -> Outcome:
        evento = dados.get("evento")
        if evento not in PERMISSOES:
            return _falha("erro", "Evento desconhecido.")
        if papel not in PERMISSOES[evento]:
            return _falha(evento, "Esta tela não pode fazer essa ação.")

        if evento == "iniciar":
            return self.iniciar()
        if evento in ("sortear", "proxima"):
            return self.avancar()
        if evento == "liberar_buzzer":
            return self.liberar_buzzer()
        if evento == "apertar_buzzer":
            return self.apertar(
                dados.get("equipe"),
                dados.get("timestamp"),
                int(time.time() * 1000),
            )
        if evento == "responder":
            return self.responder(dados.get("equipe"))
        if evento == "passar":
            return self.passar(dados.get("equipe"))
        if evento == "selecionar_resposta":
            return self.selecionar(dados.get("alternativa"))
        if evento == "validar_resposta":
            return self.validar(dados.get("alternativa"))
        if evento == "acertou":
            return self.julgar(True)
        if evento == "errou":
            return self.julgar(False)
        return _falha("erro", "Evento desconhecido.")

    def iniciar(self) -> Outcome:
        ids = self.perguntas.sortear_ids(GameState().total, self.rng)
        self.estado = GameState(
            fase="aguardando",
            fila=ids,
            iniciada=True,
            mensagem="Partida de 10 perguntas iniciada. Sorteie a primeira.",
            historico=["Partida iniciada."],
        )
        return Outcome(True, "iniciar", self.estado.mensagem, encerrar_timer=True)

    def avancar(self) -> Outcome:
        if not self.estado.iniciada:
            return _falha("sortear", "Inicie a partida primeiro.")
        if self.estado.fase == "encerrada":
            return _falha("sortear", "A partida acabou. Inicie outra para jogar de novo.")
        if self.estado.fase not in ("aguardando", "resultado", "descartada"):
            return _falha("sortear", "Termine a rodada atual antes de avançar.")
        if not self.estado.fila:
            return self.encerrar()
        return self._sortear()

    def _sortear(self) -> Outcome:
        identificador = self.estado.fila.pop(0)
        pergunta = self.perguntas.obter(identificador)
        self.estado.pergunta = pergunta
        self.estado.valor = int(pergunta["pontos"])
        self.estado.buzzer_aberto = False
        self.estado.primeiro_toque = None
        self.estado.equipe_da_vez = None
        self.estado.passaram = []
        self.estado.alternativa = None
        self.estado.resultado = None
        self.estado.julgamento = None
        self.estado.vencedor = None
        self.estado.rodada += 1
        self.estado.fase = "leitura"
        self.estado.restante = int(pergunta["tempo_leitura"])
        self.estado.mensagem = "Pergunta {0} de {1}. Leiam em silêncio.".format(
            self.estado.rodada, self.estado.total
        )
        self._anotar(self.estado.mensagem)
        return Outcome(
            True,
            "sortear",
            self.estado.mensagem,
            timer=("leitura", self.estado.restante, True),
        )

    def liberar_buzzer(self) -> Outcome:
        if self.estado.fase == "valendo":
            return _falha("liberar_buzzer", "O buzzer já está liberado.")
        if self.estado.fase != "leitura":
            return _falha("liberar_buzzer", "Sorteie uma pergunta para liberar o buzzer.")
        return self._abrir_buzzer()

    def _abrir_buzzer(self) -> Outcome:
        self.estado.fase = "valendo"
        self.estado.buzzer_aberto = True
        self.estado.restante = TEMPO_BUZZER
        self.estado.mensagem = "Valendo! O primeiro toque responde."
        self._anotar("Buzzer liberado.")
        return Outcome(
            True,
            "liberar_buzzer",
            self.estado.mensagem,
            timer=("valendo", TEMPO_BUZZER, True),
        )

    def apertar(self, equipe, timestamp, timestamp_servidor: int) -> Outcome:
        if not isinstance(timestamp, (int, float)) or isinstance(timestamp, bool):
            timestamp = timestamp_servidor
        ok, mensagem = self.buzzer.registrar(
            self.estado, equipe, int(timestamp), int(timestamp_servidor)
        )
        if not ok:
            return _falha("apertar_buzzer", mensagem)
        self.estado.fase = "acionado"
        self.estado.restante = 0
        self.estado.mensagem = "{0} apertou primeiro!".format(nome_equipe(equipe))
        self._anotar(self.estado.mensagem)
        return Outcome(
            True,
            "buzzer_acionado",
            self.estado.mensagem,
            timer=("acionado", TEMPO_ANIMACAO, False),
        )

    def responder(self, equipe=None) -> Outcome:
        erro = self._checar_vez("responder", equipe)
        if erro:
            return erro
        self.estado.fase = "escolher"
        self.estado.mensagem = "{0} vai responder. Vale {1} pontos.".format(
            nome_equipe(self.estado.equipe_da_vez), self.estado.valor
        )
        self._anotar(self.estado.mensagem)
        return Outcome(True, "responder", self.estado.mensagem, encerrar_timer=True)

    def passar(self, equipe=None) -> Outcome:
        if self.estado.fase not in ("acionado", "escolher"):
            return _falha("passar", "Não há uma equipe na vez de passar.")
        if not self.estado.equipe_da_vez:
            return _falha("passar", "Ninguém tomou a pergunta ainda.")
        if equipe is None:
            equipe = self.estado.equipe_da_vez
        if equipe != self.estado.equipe_da_vez:
            return _falha("passar", "Só quem está na vez pode passar.")
        if equipe in self.estado.passaram:
            return _falha("passar", "{0} já passou nesta pergunta.".format(nome_equipe(equipe)))

        destino = outra_equipe(equipe)
        self.estado.passaram.append(equipe)
        self.estado.alternativa = None
        self.estado.buzzer_aberto = False

        if destino in self.estado.passaram:
            self.estado.fase = "descartada"
            self.estado.resultado = "descarte"
            self.estado.equipe_da_vez = None
            self.estado.restante = 0
            self.estado.mensagem = (
                "Os dois grupos passaram. Quem passou não responde. Pergunta descartada."
            )
            if not self.estado.fila:
                self.estado.mensagem += " Era a última. Avance para o resultado final."
            self._anotar(self.estado.mensagem)
            return Outcome(
                True,
                "passar",
                self.estado.mensagem,
                encerrar_timer=True,
                extras=["encerrar_rodada"],
            )

        self.estado.equipe_da_vez = destino
        self.estado.valor = VALOR_PASSE
        self.estado.fase = "escolher"
        self.estado.resultado = None
        self.estado.mensagem = (
            "{0} passou. Agora vale {1} para {2}. {0} não responde."
        ).format(nome_equipe(equipe), VALOR_PASSE, nome_equipe(destino))
        self._anotar(self.estado.mensagem)
        return Outcome(True, "passar", self.estado.mensagem, encerrar_timer=True)

    def selecionar(self, alternativa) -> Outcome:
        letra = str(alternativa or "").strip().upper()
        if letra not in ("A", "B", "C", "D"):
            return _falha("selecionar_resposta", "Escolha A, B, C ou D.")
        if self.estado.fase not in ("acionado", "escolher"):
            return _falha("selecionar_resposta", "Ainda não é hora de marcar a resposta.")
        self.estado.alternativa = letra
        self.estado.mensagem = "Alternativa {0} marcada. Valide quando a turma responder.".format(letra)
        return Outcome(True, "selecionar_resposta", self.estado.mensagem)

    def validar(self, alternativa=None) -> Outcome:
        if self.estado.fase not in ("acionado", "escolher"):
            return _falha("validar_resposta", "Não há resposta em aberto.")
        if not self.estado.equipe_da_vez or self.estado.equipe_da_vez in self.estado.passaram:
            return _falha("validar_resposta", "Essa equipe não pode responder.")
        if alternativa:
            letra = str(alternativa).strip().upper()
            if letra not in ("A", "B", "C", "D"):
                return _falha("validar_resposta", "Escolha A, B, C ou D.")
            self.estado.alternativa = letra
        if not self.estado.alternativa:
            return _falha("validar_resposta", "Selecione A, B, C ou D antes de validar.")
        acerto = self.estado.alternativa == self.estado.pergunta["resposta_correta"]
        return self._pontuar(acerto, "automatico")

    def julgar(self, acerto: bool) -> Outcome:
        if self.estado.fase not in ("acionado", "escolher"):
            return _falha("validar_resposta", "Não há equipe respondendo.")
        if not self.estado.equipe_da_vez or self.estado.equipe_da_vez in self.estado.passaram:
            return _falha("validar_resposta", "Essa equipe não pode responder.")
        return self._pontuar(acerto, "manual")

    def _pontuar(self, acerto: bool, julgamento: str) -> Outcome:
        equipe = self.estado.equipe_da_vez
        ganhos = self.estado.valor if acerto else 0
        self.estado.placar[equipe] += ganhos
        self.estado.resultado = "acerto" if acerto else "erro"
        self.estado.julgamento = julgamento
        self.estado.fase = "resultado"
        self.estado.buzzer_aberto = False
        self.estado.restante = 0
        if acerto:
            texto = "{0} acertou! +{1} pontos.".format(nome_equipe(equipe), ganhos)
        else:
            texto = "{0} errou. 0 ponto.".format(nome_equipe(equipe))
        if not self.estado.fila:
            texto += " Era a última pergunta. Avance para o resultado final."
        self.estado.mensagem = texto
        self._anotar(texto)
        return Outcome(
            True,
            "validar_resposta",
            texto,
            encerrar_timer=True,
            extras=["atualizar_placar", "encerrar_rodada"],
        )

    def encerrar(self) -> Outcome:
        if not self.estado.iniciada:
            return _falha("encerrar_rodada", "Não há partida para encerrar.")
        azul = self.estado.placar["azul"]
        vermelho = self.estado.placar["vermelho"]
        self.estado.fase = "encerrada"
        self.estado.buzzer_aberto = False
        self.estado.restante = 0
        self.estado.equipe_da_vez = None
        if azul > vermelho:
            self.estado.vencedor = "azul"
            texto = "Azul venceu por {0} a {1}!".format(azul, vermelho)
        elif vermelho > azul:
            self.estado.vencedor = "vermelho"
            texto = "Vermelho venceu por {0} a {1}!".format(vermelho, azul)
        else:
            self.estado.vencedor = "empate"
            texto = "Empate em {0} a {1}!".format(azul, vermelho)
        self.estado.mensagem = texto
        self._anotar(texto)
        return Outcome(True, "encerrar_rodada", texto, encerrar_timer=True)

    def concluir_timer(self, kind: str) -> Outcome:
        if kind == "leitura" and self.estado.fase == "leitura":
            return self._abrir_buzzer()
        if kind == "valendo" and self.estado.fase == "valendo" and self.estado.primeiro_toque is None:
            self.estado.buzzer_aberto = False
            self.estado.fase = "descartada"
            self.estado.resultado = "descarte"
            self.estado.restante = 0
            self.estado.mensagem = "Ninguém apertou em 10 segundos. Pergunta descartada."
            if not self.estado.fila:
                self.estado.mensagem += " Era a última. Avance para o resultado final."
            self._anotar(self.estado.mensagem)
            return Outcome(True, "encerrar_rodada", self.estado.mensagem)
        if kind == "acionado" and self.estado.fase == "acionado":
            self.estado.fase = "escolher"
            self.estado.mensagem = "Vez de {0}. Responder ou passar? Vale {1}.".format(
                nome_equipe(self.estado.equipe_da_vez), self.estado.valor
            )
            return Outcome(True, "estado", self.estado.mensagem)
        return Outcome(False, "ignorado", "")

    def _checar_vez(self, evento: str, equipe) -> Outcome | None:
        if self.estado.fase not in ("acionado", "escolher"):
            return _falha(evento, "Ninguém está na vez de responder.")
        if not self.estado.equipe_da_vez:
            return _falha(evento, "Ninguém apertou o buzzer.")
        if equipe and equipe != self.estado.equipe_da_vez:
            return _falha(evento, "Não é a vez dessa equipe.")
        if self.estado.equipe_da_vez in self.estado.passaram:
            return _falha(evento, "Quem passou não responde.")
        return None

    def _anotar(self, texto: str) -> None:
        self.estado.historico.append(texto)
        del self.estado.historico[:-8]


class GameService:
    def __init__(
        self,
        manager,
        perguntas: QuestionService | None = None,
        tick_seconds: float = 1.0,
        rng: random.Random | None = None,
    ):
        self.manager = manager
        self.tick_seconds = tick_seconds
        self.partida = Partida(perguntas or QuestionService(), rng=rng)
        self._lock = None
        self._token = 0
        self._versao = 0
        self._task = None

    def estado_para(self, papel: str) -> dict:
        dados = self.partida.estado.para_dict(papel == "painel")
        dados["versao"] = self._versao
        return dados

    def _snaps(self) -> dict:
        self._versao += 1
        return {
            "painel": self.estado_para("painel"),
            "buzzer": self.estado_para("buzzer"),
        }

    def _trava(self):
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def _armar(self, kind: str, seconds: int, contar: bool = True) -> None:
        self._token += 1
        token = self._token
        self._task = asyncio.create_task(self._loop(token, kind, int(seconds), contar))

    def cancelar_timers(self) -> None:
        self._token += 1
        task = self._task
        if task and not task.done():
            task.cancel()

    def reiniciar_para_testes(self) -> None:
        self.cancelar_timers()
        self.partida = Partida(self.partida.perguntas)
        self._lock = None
        self._versao = 0

    async def handle(self, papel: str, dados: dict, websocket) -> None:
        if not isinstance(dados, dict):
            dados = {}
        async with self._trava():
            outcome = self.partida.aplicar(papel, dados)
            if outcome.ok and (outcome.encerrar_timer or outcome.timer):
                self._token += 1
            snaps = self._snaps()
            token = self._token
        await self._emitir(outcome, snaps, websocket, papel)
        if outcome.ok and outcome.timer:
            async with self._trava():
                if token == self._token:
                    self._armar(*outcome.timer)

    async def _emitir(self, outcome: Outcome, snaps: dict, websocket, papel: str) -> None:
        if outcome.evento == "ignorado":
            return
        if not outcome.ok:
            if websocket is not None:
                await self.manager.send_personal(
                    websocket,
                    {
                        "evento": outcome.evento,
                        "ok": False,
                        "mensagem": outcome.mensagem,
                        "estado": snaps.get(papel) or snaps["painel"],
                    },
                )
            return
        await self._publicar(outcome, snaps)

    async def _publicar(self, outcome: Outcome, snaps: dict) -> None:
        eventos = [outcome.evento, *outcome.extras]
        for evento in eventos:
            await self.manager.broadcast(evento, outcome.mensagem, snaps, ok=True)

    async def _loop(self, token: int, kind: str, seconds: int, contar: bool) -> None:
        try:
            if contar:
                for left in range(seconds, 0, -1):
                    if token != self._token:
                        return
                    async with self._trava():
                        if token != self._token:
                            return
                        self.partida.estado.restante = left
                        snaps = self._snaps()
                    await self.manager.broadcast("tick", str(left), snaps, ok=True)
                    await asyncio.sleep(self.tick_seconds)
            else:
                await asyncio.sleep(self.tick_seconds * max(seconds, 0))

            async with self._trava():
                if token != self._token:
                    return
                outcome = self.partida.concluir_timer(kind)
                snaps = self._snaps()
                seguir = outcome.timer if outcome.ok else None
            if outcome.ok and outcome.evento != "ignorado":
                await self._publicar(outcome, snaps)
            if seguir:
                async with self._trava():
                    if token == self._token:
                        self._armar(*seguir)
        except asyncio.CancelledError:
            return
        except Exception:
            logger.exception("Falha no cronômetro da partida")
