"""Carrega o banco e sorteia perguntas sem repetir."""

from __future__ import annotations

import json
import random
from pathlib import Path

from backend.app.models.question import validar_pergunta


CAMINHO_PADRAO = Path(__file__).resolve().parents[2] / "data" / "perguntas.json"


class QuestionService:
    def __init__(self, caminho: Path | None = None):
        self.caminho = Path(caminho) if caminho else CAMINHO_PADRAO
        self.perguntas = self._carregar(self.caminho)
        self._por_id = {item["id"]: item for item in self.perguntas}

    @staticmethod
    def _carregar(caminho: Path) -> list:
        bruto = json.loads(caminho.read_text(encoding="utf-8"))
        if not isinstance(bruto, list) or not bruto:
            raise ValueError("O banco de perguntas está vazio.")
        ids: set = set()
        perguntas = [validar_pergunta(item, ids).para_dict() for item in bruto]
        return perguntas

    def todas(self) -> list:
        return list(self.perguntas)

    def obter(self, identificador: int) -> dict:
        pergunta = self._por_id[identificador]
        return {
            "id": pergunta["id"],
            "categoria": pergunta["categoria"],
            "pergunta": pergunta["pergunta"],
            "alternativas": dict(pergunta["alternativas"]),
            "resposta_correta": pergunta["resposta_correta"],
            "pontos": pergunta["pontos"],
            "tempo_leitura": pergunta["tempo_leitura"],
        }

    def sortear_ids(self, quantidade: int, rng: random.Random | None = None) -> list:
        gerador = rng or random.Random()
        ids = [item["id"] for item in self.perguntas]
        if quantidade > len(ids):
            raise ValueError("Não há perguntas suficientes para esta partida.")
        return gerador.sample(ids, quantidade)
