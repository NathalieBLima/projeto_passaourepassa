"""Instâncias únicas do servidor: conexões e partida."""

from backend.app.services.game_service import GameService
from backend.app.websocket_manager import ConnectionManager


manager = ConnectionManager()
jogo = GameService(manager)
