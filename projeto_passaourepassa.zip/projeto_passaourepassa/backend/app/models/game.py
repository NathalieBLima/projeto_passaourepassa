"""Estado da partida. O servidor é a fonte da verdade."""

from __future__ import annotations

from dataclasses import dataclass, field


TOTAL_PERGUNTAS = 10
TEMPO_BUZZER = 10
TEMPO_ANIMACAO = 2
VALOR_PASSE = 20


def nome_equipe(equipe: str) -> str:
    if equipe == "azul":
        return "Azul"
    if equipe == "vermelho":
        return "Vermelho"
    return "Equipe"


def outra_equipe(equipe: str) -> str:
    return "vermelho" if equipe == "azul" else "azul"


@dataclass
class GameState:
    fase: str = "idle"
    placar: dict = field(default_factory=lambda: {"azul": 0, "vermelho": 0})
    rodada: int = 0
    total: int = TOTAL_PERGUNTAS
    fila: list = field(default_factory=list)
    pergunta: dict | None = None
    valor: int = 10
    buzzer_aberto: bool = False
    primeiro_toque: dict | None = None
    equipe_da_vez: str | None = None
    passaram: list = field(default_factory=list)
    alternativa: str | None = None
    resultado: str | None = None
    julgamento: str | None = None
    mensagem: str = "Aguardando a professora iniciar a partida."
    restante: int = 0
    vencedor: str | None = None
    historico: list = field(default_factory=list)
    iniciada: bool = False

    def tela(self) -> str:
        if self.fase in ("idle", "aguardando"):
            return "aguarde"
        if self.fase == "leitura":
            return "leiam"
        if self.fase == "valendo":
            return "valendo"
        if self.fase == "acionado":
            equipe = (self.primeiro_toque or {}).get("equipe")
            if equipe == "vermelho":
                return "vermelho_apertou"
            return "azul_apertou"
        if self.fase == "escolher":
            return "escolher"
        if self.fase == "encerrada":
            return "encerrada"
        if self.fase == "descartada":
            return "descartada"
        if self.fase == "resultado":
            return "resultado"
        return "aguarde"

    def para_dict(self, painel: bool) -> dict:
        revelar = self.fase in ("resultado", "descartada", "encerrada")
        pergunta = None
        if self.pergunta:
            pergunta = {
                "id": self.pergunta["id"],
                "categoria": self.pergunta["categoria"],
                "pergunta": self.pergunta["pergunta"],
                "alternativas": dict(self.pergunta["alternativas"]),
                "pontos": self.pergunta["pontos"],
                "tempo_leitura": self.pergunta["tempo_leitura"],
            }
        pode_marcar = self.fase in ("acionado", "escolher")
        pode_julgar = pode_marcar and bool(self.equipe_da_vez) and self.equipe_da_vez not in self.passaram
        return {
            "fase": self.fase,
            "tela": self.tela(),
            "placar": {"azul": self.placar["azul"], "vermelho": self.placar["vermelho"]},
            "rodada": self.rodada,
            "total": self.total,
            "restantes": len(self.fila),
            "pergunta": pergunta,
            "valor": self.valor,
            "buzzer_aberto": self.buzzer_aberto,
            "primeiro_toque": dict(self.primeiro_toque) if self.primeiro_toque else None,
            "equipe_da_vez": self.equipe_da_vez,
            "passaram": list(self.passaram),
            "alternativa": self.alternativa,
            "resultado": self.resultado,
            "julgamento": self.julgamento,
            "mensagem": self.mensagem,
            "restante": self.restante,
            "vencedor": self.vencedor,
            "historico": list(self.historico) if painel else [],
            "iniciada": self.iniciada,
            "gabarito": self.pergunta["resposta_correta"] if painel and revelar and self.pergunta else None,
            "pode_apertar": self.fase == "valendo" and self.buzzer_aberto,
            "pode_decidir": self.fase == "escolher" and pode_julgar,
            "pode_marcar": pode_marcar,
            "pode_julgar": pode_julgar,
            "pode_validar": pode_julgar and bool(self.alternativa),
            "pode_passar": pode_julgar and self.equipe_da_vez not in self.passaram,
            "pode_avancar": self.iniciada and self.fase in ("aguardando", "resultado", "descartada"),
            "pode_liberar": self.fase == "leitura",
            "pode_iniciar": True,
        }
