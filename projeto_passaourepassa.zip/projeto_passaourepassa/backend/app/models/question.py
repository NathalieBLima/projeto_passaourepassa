"""Pergunta do banco da turma."""

from __future__ import annotations

from dataclasses import asdict, dataclass


CATEGORIAS = {
    "conhecimentos gerais",
    "ciências",
    "matemática/lógica",
    "robótica",
    "programação",
}
LETRAS = ("A", "B", "C", "D")


@dataclass(frozen=True)
class Question:
    id: int
    categoria: str
    pergunta: str
    alternativas: dict
    resposta_correta: str
    pontos: int = 10
    tempo_leitura: int = 5

    def para_dict(self) -> dict:
        return asdict(self)


def validar_pergunta(bruto: dict, ids_vistos: set) -> Question:
    if not isinstance(bruto, dict):
        raise ValueError("Cada pergunta precisa ser um objeto.")

    faltando = [
        campo
        for campo in (
            "id",
            "categoria",
            "pergunta",
            "alternativas",
            "resposta_correta",
            "pontos",
            "tempo_leitura",
        )
        if campo not in bruto
    ]
    if faltando:
        raise ValueError("Pergunta sem campos: {0}.".format(", ".join(faltando)))

    try:
        identificador = int(bruto["id"])
        pontos = int(bruto["pontos"])
        tempo = int(bruto["tempo_leitura"])
    except (TypeError, ValueError) as exc:
        raise ValueError("id, pontos e tempo_leitura precisam ser números.") from exc

    if identificador in ids_vistos:
        raise ValueError("Pergunta repetida: id {0}.".format(identificador))
    ids_vistos.add(identificador)

    categoria = str(bruto["categoria"]).strip()
    if categoria not in CATEGORIAS:
        raise ValueError("Categoria inválida na pergunta {0}.".format(identificador))

    texto = str(bruto["pergunta"]).strip()
    if not texto:
        raise ValueError("Pergunta {0} está vazia.".format(identificador))

    alternativas = bruto["alternativas"]
    if not isinstance(alternativas, dict) or set(alternativas) != set(LETRAS):
        raise ValueError("A pergunta {0} precisa das alternativas A, B, C e D.".format(identificador))
    limpas = {}
    for letra in LETRAS:
        opcao = str(alternativas[letra]).strip()
        if not opcao:
            raise ValueError("Alternativa {0} vazia na pergunta {1}.".format(letra, identificador))
        limpas[letra] = opcao

    correta = str(bruto["resposta_correta"]).strip().upper()
    if correta not in LETRAS:
        raise ValueError("resposta_correta inválida na pergunta {0}.".format(identificador))

    if pontos <= 0 or tempo <= 0:
        raise ValueError("pontos e tempo_leitura precisam ser positivos (pergunta {0}).".format(identificador))

    return Question(
        id=identificador,
        categoria=categoria,
        pergunta=texto,
        alternativas=limpas,
        resposta_correta=correta,
        pontos=pontos,
        tempo_leitura=tempo,
    )
