"""Modelos da partida e das perguntas."""
