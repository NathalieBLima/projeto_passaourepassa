"""Servidor do Passa ou Repassa da Turma.

Rode na raiz do projeto:

    uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from backend.app.container import jogo
from backend.app.routes.pages import router as pages_router
from backend.app.routes.websocket import router as ws_router


BASE = Path(__file__).resolve().parent


class Estaticos(StaticFiles):
    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache"
        return response


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    jogo.cancelar_timers()


def create_app() -> FastAPI:
    app = FastAPI(title="Passa ou Repassa da Turma", lifespan=lifespan)
    app.mount("/static", Estaticos(directory=str(BASE / "static")), name="static")
    app.include_router(pages_router)
    app.include_router(ws_router)
    return app


app = create_app()
