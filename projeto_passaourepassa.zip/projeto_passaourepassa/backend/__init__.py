"""Passa ou Repassa da Turma."""
