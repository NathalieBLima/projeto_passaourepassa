(function () {
  var versaoVista = -1;
  var socket = null;
  var estadoAtual = null;
  var toqueLocal = false;
  var ultimoTick = "";

  var azul = document.getElementById("btn-azul");
  var vermelho = document.getElementById("btn-vermelho");
  var responder = document.getElementById("btn-responder");
  var passar = document.getElementById("btn-passar");
  var decisao = document.getElementById("decisao");
  var animacao = document.getElementById("animacao");
  var conexao = document.getElementById("conexao");

  var rotulos = {
    aguarde: "AGUARDE",
    leiam: "LEIAM",
    valendo: "VALENDO",
    azul_apertou: "AZUL",
    vermelho_apertou: "VERMELHO",
    escolher: "ESCOLHER",
    encerrada: "ENCERRADA",
    descartada: "DESCARTADA",
    resultado: "RESULTADO"
  };

  function enviar(evento, extra) {
    if (!socket || socket.readyState !== 1) return;
    socket.send(JSON.stringify(Object.assign({ evento: evento }, extra || {})));
  }

  function aplicarBloqueio() {
    var aberto = !!(estadoAtual && estadoAtual.pode_apertar && !toqueLocal);
    azul.disabled = !aberto;
    vermelho.disabled = !aberto;
  }

  function render(estado) {
    if (typeof estado.versao === "number") {
      if (estado.versao < versaoVista) return;
      versaoVista = estado.versao;
    }
    estadoAtual = estado;
    if (estado.fase !== "valendo") toqueLocal = false;

    document.getElementById("placar-azul").textContent = estado.placar.azul;
    document.getElementById("placar-vermelho").textContent = estado.placar.vermelho;

    var tela = estado.tela || "aguarde";
    document.body.classList.remove(
      "tela-aguarde", "tela-leiam", "tela-valendo", "tela-azul_apertou",
      "tela-vermelho_apertou", "tela-escolher", "tela-encerrada",
      "tela-descartada", "tela-resultado"
    );
    document.body.classList.add("tela-" + tela);

    var titulo = rotulos[tela] || "AGUARDE";
    if ((tela === "leiam" || tela === "valendo") && estado.restante) {
      titulo += " " + estado.restante;
    }
    if (tela === "resultado") {
      titulo = estado.resultado === "acerto" ? "ACERTOU +" + estado.valor : "ERROU";
    }
    if (tela === "encerrada") {
      if (estado.vencedor === "empate") titulo = "EMPATE";
      else if (estado.vencedor) titulo = estado.vencedor.toUpperCase() + " VENCEU";
    }
    document.getElementById("estado-tela").textContent = titulo;
    document.getElementById("kicker").textContent = estado.valor >= 20 ? "vale 20" : "vale " + (estado.valor || 10);
    document.getElementById("mensagem").textContent = estado.mensagem || "";

    var apertou = tela === "azul_apertou" || tela === "vermelho_apertou";
    animacao.hidden = !apertou;
    animacao.classList.toggle("azul", tela === "azul_apertou");
    animacao.classList.toggle("vermelho", tela === "vermelho_apertou");
    document.getElementById("animacao-equipe").textContent = tela === "vermelho_apertou" ? "VERMELHO" : "AZUL";

    var podeDecidir = !!estado.pode_decidir;
    decisao.hidden = !podeDecidir;
    responder.disabled = !podeDecidir;
    passar.disabled = !podeDecidir;
    if (podeDecidir && estado.equipe_da_vez) {
      var nome = estado.equipe_da_vez === "azul" ? "AZUL" : "VERMELHO";
      responder.textContent = nome + " RESPONDE";
      passar.textContent = nome + " PASSA";
    } else {
      responder.textContent = "RESPONDER";
      passar.textContent = "PASSAR";
    }
    aplicarBloqueio();
  }

  function efeito(msg) {
    if (!msg || msg.ok === false || !window.Som) return;
    var fase = msg.estado ? msg.estado.fase : "";
    if (msg.evento === "liberar_buzzer") Som.tocar("liberar");
    if (msg.evento === "buzzer_acionado") {
      Som.tocar("buzz");
      if (navigator.vibrate) navigator.vibrate(180);
    }
    if (msg.evento === "passar" && fase !== "descartada") Som.tocar("passar");
    if (msg.evento === "validar_resposta") {
      Som.tocar(msg.estado && msg.estado.resultado === "acerto" ? "acerto" : "erro");
    }
    if (msg.evento === "encerrar_rodada" && fase === "encerrada") Som.tocar("vitoria");
    if (msg.evento === "encerrar_rodada" && fase === "descartada") Som.tocar("erro");
    if (msg.evento === "tick" && msg.estado && msg.estado.fase === "valendo" && msg.estado.restante <= 3) {
      if (ultimoTick !== String(msg.estado.restante)) {
        ultimoTick = String(msg.estado.restante);
        Som.tocar("tick");
      }
    }
  }

  function apertar(equipe, ev) {
    ev.preventDefault();
    if (toqueLocal || !estadoAtual || !estadoAtual.pode_apertar) return;
    toqueLocal = true;
    aplicarBloqueio();
    if (navigator.vibrate) navigator.vibrate(40);
    enviar("apertar_buzzer", { equipe: equipe, timestamp: Date.now() });
  }

  azul.addEventListener("pointerdown", function (ev) { apertar("azul", ev); });
  vermelho.addEventListener("pointerdown", function (ev) { apertar("vermelho", ev); });
  [azul, vermelho].forEach(function (botao) {
    botao.addEventListener("contextmenu", function (ev) { ev.preventDefault(); });
  });

  responder.addEventListener("pointerdown", function (ev) {
    ev.preventDefault();
    if (!estadoAtual || !estadoAtual.pode_decidir) return;
    enviar("responder", { equipe: estadoAtual.equipe_da_vez });
  });
  passar.addEventListener("pointerdown", function (ev) {
    ev.preventDefault();
    if (!estadoAtual || !estadoAtual.pode_decidir) return;
    enviar("passar", { equipe: estadoAtual.equipe_da_vez });
  });

  function conectar() {
    var protocolo = location.protocol === "https:" ? "wss" : "ws";
    socket = new WebSocket(protocolo + "://" + location.host + "/ws/buzzer");
    socket.onopen = function () { conexao.textContent = ""; };
    socket.onclose = function () {
      conexao.textContent = "reconectando…";
      setTimeout(conectar, 1000);
    };
    socket.onmessage = function (ev) {
      var msg = JSON.parse(ev.data);
      if (msg.ok === false && msg.evento === "apertar_buzzer") toqueLocal = false;
      if (msg.estado) render(msg.estado);
      efeito(msg);
    };
  }

  conectar();
})();
