(function () {
  var volumes = {
    buzz: 0.9,
    acerto: 0.75,
    erro: 0.7,
    tick: 0.35,
    liberar: 0.75,
    passar: 0.7,
    vitoria: 0.8,
    inicio: 0.7
  };

  function tocar(nome) {
    var audio = new Audio("/static/sounds/" + nome + ".wav");
    audio.volume = volumes[nome] || 0.7;
    audio.play().catch(function () {});
  }

  function destravar() {
    Object.keys(volumes).forEach(function (nome) {
      var audio = new Audio("/static/sounds/" + nome + ".wav");
      audio.volume = 0.001;
      audio.play().then(function () {
        audio.pause();
      }).catch(function () {});
    });
    var aviso = document.getElementById("ativar-som");
    if (aviso) aviso.hidden = true;
    document.body.classList.add("som-ativo");
  }

  var botao = document.getElementById("ativar-som");
  if (botao) botao.addEventListener("click", destravar);
  document.addEventListener("pointerdown", destravar, { once: true });
  window.Som = { tocar: tocar, destravar: destravar };
})();
