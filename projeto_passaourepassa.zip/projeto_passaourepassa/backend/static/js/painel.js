(function () {
  var versaoVista = -1;
  var socket = null;
  var estadoAtual = null;
  var placarAnterior = { azul: null, vermelho: null };
  var letras = ["A", "B", "C", "D"];

  var conexao = document.getElementById("conexao");
  var aviso = document.getElementById("aviso");

  function nome(equipe) {
    if (equipe === "azul") return "Azul";
    if (equipe === "vermelho") return "Vermelho";
    return "";
  }

  function enviar(evento, extra) {
    if (!socket || socket.readyState !== 1) {
      mostrarAviso("O painel não está conectado.");
      return;
    }
    var pacote = Object.assign({ evento: evento }, extra || {});
    socket.send(JSON.stringify(pacote));
  }

  function mostrarAviso(texto) {
    aviso.hidden = !texto;
    aviso.textContent = texto || "";
  }

  function render(estado) {
    if (typeof estado.versao === "number") {
      if (estado.versao < versaoVista) return;
      versaoVista = estado.versao;
    }
    estadoAtual = estado;

    document.getElementById("placar-azul").textContent = estado.placar.azul;
    document.getElementById("placar-vermelho").textContent = estado.placar.vermelho;
    ["azul", "vermelho"].forEach(function (equipe) {
      var caixa = document.querySelector(".time." + equipe);
      if (placarAnterior[equipe] !== null && placarAnterior[equipe] !== estado.placar[equipe]) {
        caixa.classList.remove("pulou");
        void caixa.offsetWidth;
        caixa.classList.add("pulou");
      }
      placarAnterior[equipe] = estado.placar[equipe];
    });

    var rodada = estado.rodada || 0;
    document.getElementById("rodada").textContent = estado.fase === "encerrada"
      ? "Partida encerrada"
      : "Pergunta " + rodada + " de " + estado.total;
    var valor = document.getElementById("valor");
    valor.textContent = "Vale " + estado.valor;
    valor.style.background = estado.valor >= 20 ? "#fdba74" : "";

    var pergunta = estado.pergunta;
    document.getElementById("categoria").textContent = pergunta ? pergunta.categoria : "Aguardando";
    document.getElementById("pergunta").textContent = pergunta
      ? pergunta.pergunta
      : "Inicie a partida e sorteie a primeira pergunta.";

    letras.forEach(function (letra) {
      var botao = document.getElementById("alt-" + letra);
      var texto = pergunta ? pergunta.alternativas[letra] : "";
      botao.querySelector("span").textContent = texto;
      botao.disabled = !estado.pode_marcar;
      botao.classList.toggle("selecionada", estado.alternativa === letra);
      botao.classList.toggle("correta", !!estado.gabarito && estado.gabarito === letra);
      botao.classList.toggle(
        "errada",
        estado.resultado === "erro" && estado.alternativa === letra && estado.gabarito !== letra
      );
    });

    var gabarito = document.getElementById("gabarito");
    if (estado.gabarito) {
      gabarito.hidden = false;
      gabarito.textContent = "Resposta oficial: " + estado.gabarito;
    } else {
      gabarito.hidden = true;
    }

    var toque = document.getElementById("toque");
    if (estado.primeiro_toque) {
      toque.hidden = false;
      toque.textContent = nome(estado.primeiro_toque.equipe) +
        " apertou aos " + estado.primeiro_toque.timestamp + " ms";
    } else {
      toque.hidden = true;
    }

    document.getElementById("mensagem").textContent = estado.mensagem || "";
    var cronometro = document.getElementById("cronometro");
    var caixa = document.getElementById("caixa-tempo");
    var rotulo = document.getElementById("rotulo-tempo");
    if (estado.fase === "leitura" || estado.fase === "valendo") {
      cronometro.textContent = estado.restante;
      rotulo.textContent = estado.fase === "leitura" ? "Leitura" : "Buzzer";
      caixa.classList.toggle("urgente", estado.restante > 0 && estado.restante <= 3);
    } else {
      cronometro.textContent = "–";
      rotulo.textContent = "Tempo";
      caixa.classList.remove("urgente");
    }

    document.getElementById("btn-sortear").disabled = !estado.pode_avancar;
    document.getElementById("btn-proxima").disabled = !estado.pode_avancar;
    document.getElementById("btn-liberar").disabled = !estado.pode_liberar;
    document.getElementById("btn-validar").disabled = !estado.pode_validar;
    document.getElementById("btn-acertou").disabled = !estado.pode_julgar;
    document.getElementById("btn-errou").disabled = !estado.pode_julgar;
    document.getElementById("btn-passou").disabled = !estado.pode_passar;

    var lista = document.getElementById("historico");
    lista.replaceChildren();
    (estado.historico || []).slice().reverse().forEach(function (item) {
      var li = document.createElement("li");
      li.textContent = item;
      lista.appendChild(li);
    });
  }

  function efeito(msg) {
    if (!msg || msg.ok === false || !window.Som) return;
    var fase = msg.estado ? msg.estado.fase : "";
    if (msg.evento === "iniciar") Som.tocar("inicio");
    if (msg.evento === "liberar_buzzer") Som.tocar("liberar");
    if (msg.evento === "buzzer_acionado") Som.tocar("buzz");
    if (msg.evento === "passar" && fase !== "descartada") Som.tocar("passar");
    if (msg.evento === "validar_resposta") {
      Som.tocar(msg.estado && msg.estado.resultado === "acerto" ? "acerto" : "erro");
    }
    if (msg.evento === "encerrar_rodada" && fase === "encerrada") Som.tocar("vitoria");
    if (msg.evento === "encerrar_rodada" && fase === "descartada") Som.tocar("erro");
    if (msg.evento === "tick" && msg.estado && msg.estado.fase === "valendo" && msg.estado.restante <= 3) {
      Som.tocar("tick");
    }
  }

  function conectar() {
    var protocolo = location.protocol === "https:" ? "wss" : "ws";
    socket = new WebSocket(protocolo + "://" + location.host + "/ws/painel");
    socket.onopen = function () {
      conexao.textContent = "conectado";
      conexao.className = "conexao ok";
    };
    socket.onclose = function () {
      conexao.textContent = "reconectando…";
      conexao.className = "conexao fora";
      setTimeout(conectar, 1000);
    };
    socket.onmessage = function (ev) {
      var msg = JSON.parse(ev.data);
      if (msg.ok === false) mostrarAviso(msg.mensagem);
      else mostrarAviso("");
      if (msg.estado) render(msg.estado);
      efeito(msg);
    };
  }

  document.getElementById("btn-iniciar").addEventListener("click", function () {
    if (estadoAtual && estadoAtual.rodada > 0 && estadoAtual.fase !== "encerrada") {
      if (!window.confirm("Isso zera o placar e começa outra partida. Continuar?")) return;
    }
    enviar("iniciar");
  });
  document.getElementById("btn-sortear").addEventListener("click", function () { enviar("sortear"); });
  document.getElementById("btn-proxima").addEventListener("click", function () { enviar("proxima"); });
  document.getElementById("btn-liberar").addEventListener("click", function () { enviar("liberar_buzzer"); });
  document.getElementById("btn-validar").addEventListener("click", function () { enviar("validar_resposta"); });
  document.getElementById("btn-acertou").addEventListener("click", function () { enviar("acertou"); });
  document.getElementById("btn-errou").addEventListener("click", function () { enviar("errou"); });
  document.getElementById("btn-passou").addEventListener("click", function () { enviar("passar"); });

  letras.forEach(function (letra) {
    document.getElementById("alt-" + letra).addEventListener("click", function () {
      enviar("selecionar_resposta", { alternativa: letra });
    });
  });

  document.addEventListener("keydown", function (ev) {
    if (ev.metaKey || ev.ctrlKey || ev.altKey) return;
    var tecla = ev.key.toLowerCase();
    if (["a", "b", "c", "d"].indexOf(tecla) >= 0) {
      enviar("selecionar_resposta", { alternativa: tecla.toUpperCase() });
    } else if (tecla === "v") enviar("validar_resposta");
    else if (tecla === "l") enviar("liberar_buzzer");
    else if (tecla === "p") enviar("passar");
    else if (tecla === "n") enviar("proxima");
  });

  conectar();
})();
