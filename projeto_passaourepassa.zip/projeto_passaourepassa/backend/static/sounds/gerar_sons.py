"""Gera os sons curtos usados no painel e no buzzer."""

import math
import struct
import wave
from pathlib import Path


PASTA = Path(__file__).resolve().parent
TAXA = 22050


def _envelope(i, total):
    ataque = int(TAXA * 0.01)
    solta = int(TAXA * 0.03)
    env = 1.0
    if ataque and i < ataque:
        env = i / float(ataque)
    if solta and i > total - solta:
        env = max(0.0, (total - i) / float(solta))
    return env


def gravar(nome, trechos):
    amostras = []
    for frequencia, duracao, volume in trechos:
        total = int(TAXA * duracao)
        for i in range(total):
            env = _envelope(i, total)
            onda = math.sin(2 * math.pi * frequencia * (i / float(TAXA)))
            valor = max(-1.0, min(1.0, onda * env * volume))
            amostras.append(int(valor * 32767))
    caminho = PASTA / (nome + ".wav")
    with wave.open(str(caminho), "w") as arquivo:
        arquivo.setnchannels(1)
        arquivo.setsampwidth(2)
        arquivo.setframerate(TAXA)
        arquivo.writeframes(b"".join(struct.pack("<h", amostra) for amostra in amostras))


def main():
    gravar("buzz", [(196, 0.12, 0.55), (247, 0.16, 0.55)])
    gravar("acerto", [(523, 0.09, 0.45), (659, 0.09, 0.45), (784, 0.16, 0.5)])
    gravar("erro", [(349, 0.12, 0.45), (220, 0.2, 0.5)])
    gravar("tick", [(880, 0.06, 0.35)])
    gravar("liberar", [(660, 0.08, 0.4), (880, 0.12, 0.45)])
    gravar("passar", [(494, 0.08, 0.4), (659, 0.08, 0.4), (523, 0.12, 0.4)])
    gravar("vitoria", [(523, 0.1, 0.4), (659, 0.1, 0.45), (784, 0.1, 0.45), (1046, 0.22, 0.5)])
    gravar("inicio", [(392, 0.1, 0.4), (523, 0.16, 0.45)])


if __name__ == "__main__":
    main()
