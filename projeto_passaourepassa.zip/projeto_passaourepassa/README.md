# Passa ou Repassa da Turma

Jogo de sala para dois grupos, Azul e Vermelho. A professora conduz a partida no computador e os dois grupos apertam o buzzer no mesmo tablet. O servidor é a fonte da verdade: placar, tempo e o primeiro toque ficam no FastAPI.

## Regras

- A partida tem 10 perguntas, sorteadas sem repetir entre as 30 do banco.
- Acerto vale os pontos da pergunta (10).
- A equipe da vez pode passar uma vez. A pergunta vai para o outro grupo e passa a valer 20.
- Quem passou não responde. Se os dois passarem, a pergunta é descartada.
- Erro vale 0.
- Se ninguém apertar em 10 segundos, a pergunta é descartada.
- O tablet só registra o primeiro toque depois que o buzzer é liberado. O instante do toque fica em milissegundos.

## Como rodar

Na pasta do projeto:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

- Painel da professora: http://localhost:8000/painel
- Buzzer do tablet: http://IP_DO_PC:8000/buzzer

O computador e o tablet Android precisam estar no mesmo Wi-Fi. Para ver o IP do Mac:

```bash
ipconfig getifaddr en0
```

Abra `http://IP_DO_PC:8000/buzzer` no Chrome do tablet. Na primeira vez, toque em **Ativar som**. Se o Mac pedir permissão para aceitar conexões, permita.

A página inicial também mostra o endereço do buzzer quando o servidor consegue descobrir o IP da rede.

## Como jogar

1. No painel, clique em **Iniciar partida** e depois em **Sortear pergunta**.
2. A turma lê por 5 segundos. O buzzer abre sozinho, ou a professora clica em **Liberar buzzer** antes.
3. Azul aperta o lado esquerdo e Vermelho o lado direito. Os botões ficam bloqueados antes e depois do primeiro toque.
4. No tablet, a equipe da vez toca em **RESPONDER** ou **PASSAR**.
5. A professora marca A, B, C ou D e clica em **Validar resposta**. **Acertou** e **Errou** servem para o julgamento manual.
6. **Próxima** segue para a outra pergunta. Depois da décima, ela abre o resultado final.

O gabarito só aparece no painel depois da validação, para a pergunta poder ficar projetada.

## Eventos WebSocket

O painel usa `/ws/painel` e o tablet usa `/ws/buzzer`.

- `iniciar`
- `sortear`
- `liberar_buzzer`
- `apertar_buzzer` (o tablet envia `equipe` e `timestamp` em ms)
- `buzzer_acionado`
- `responder`
- `passar`
- `validar_resposta`
- `atualizar_placar`
- `encerrar_rodada`

`tick` e `estado` só sincronizam cronômetro e reconexão. `selecionar_resposta` guarda a letra marcada pela professora.

## Testes

```bash
pytest
```

## Estrutura

```text
backend/main.py
backend/app/routes/pages.py
backend/app/routes/websocket.py
backend/app/services/game_service.py
backend/app/services/question_service.py
backend/app/services/buzzer_service.py
backend/app/models/game.py
backend/app/models/question.py
backend/app/websocket_manager.py
backend/data/perguntas.json
backend/static/css
backend/static/js
backend/static/sounds
backend/templates/index.html
backend/templates/painel.html
backend/templates/buzzer.html
tests/
```
